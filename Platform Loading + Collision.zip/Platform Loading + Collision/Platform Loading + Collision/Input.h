#pragma once
#include "stdafx.h"

class Entity;
class MeleeEnemy;
class Jumper;
class WorldObject;

class Input{
public:
	Input(){
		ClearInputs();
	}
	virtual ~Input(){}

	virtual void Update(Entity *g, std::vector<WorldObject*> &objs){}
	virtual void Update(MeleeEnemy *g, std::vector<WorldObject*> &objs){}
	virtual void Update(Jumper *g, sf::Vector2f &velocity, const int maxHorizVelocity, const int jumpVelocity, bool &facingLeft, bool &canjump, bool &collided, std::vector<WorldObject*> &objs, sf::Clock &clock){}

	//called every gameloop
	void ClearInputs(){
		moveLeft = false;
		moveRight = false;
		jump = false;
		attack = false;
	}

	void MoveLeft(){
		moveLeft = true;
	}
	void MoveRight(){
		moveRight = true;
	}
	void Jump(){
		jump = true;
	}
	void Attack(){
		attack = true;
	}

	virtual void UpdatePos(const sf::Vector2f &pos){}
	virtual void UpReleased(bool torf){}

	bool GetMoveLeft(){
		return moveLeft;
	}
	bool GetMoveRight(){
		return moveRight;
	}
	bool GetJump(){
		return jump;
	}
	bool GetAttack(){
		return attack;
	}
	virtual bool GetUpReleased(){
		return false;
	}
protected:
	bool moveLeft;
	bool moveRight;
	bool jump;
	bool attack;

	sf::Vector2f playerPos;
};
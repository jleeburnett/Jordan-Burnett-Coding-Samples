#pragma once
#include "stdafx.h"

class Entity;

class WeaponBehavior{
public:
	WeaponBehavior(){}
	virtual ~WeaponBehavior(){}
	
	virtual void Update(sf::Clock &clock, Entity *owner, bool &remove, sf::ConvexShape &shape, sf::Vector2f &startPos){
		
	}
protected:
	double timeAttackLasts;
	double timeOfLastAttack;
};
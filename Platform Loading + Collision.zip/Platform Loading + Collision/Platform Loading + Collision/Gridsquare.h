#pragma once
#include "stdafx.h"

class Gridsquare{
public:
	Gridsquare(int x, int y, int width, int height){
		rect = sf::FloatRect(x, y, width, height);
	}

	void AddObject(WorldObject *o){
		objects.push_back(o);
	}

	sf::FloatRect &GetRect(){
		return rect;
	}

	std::vector<WorldObject*> &GetObjects(){
		return objects;
	}
private:
	sf::FloatRect rect;
	//vec of object pointers
	std::vector<WorldObject*> objects;
};
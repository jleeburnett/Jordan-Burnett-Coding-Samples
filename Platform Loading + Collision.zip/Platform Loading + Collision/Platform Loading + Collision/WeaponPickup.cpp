#include "stdafx.h"
#include "WeaponPickup.h"
#include "Jumper.h"
#include "Weapon.h"

WeaponPickup::WeaponPickup(Weapon *w, int posX, int posY, int tileSize){
	weapon = w;
	if(weapon->GetWeaponScale() == 0){
		shape.setFillColor(sf::Color::Yellow);
	}
	else if(weapon->GetWeaponScale() == 1){
		shape.setFillColor(sf::Color::White);
	}
	else if(weapon->GetWeaponScale() == 2){
		shape.setFillColor(sf::Color(180, 180, 180));
	}

	shape.setPointCount(4);
	shape.setPoint(0, sf::Vector2f(tileSize, 0));
	shape.setPoint(1, sf::Vector2f(0, 0));
	shape.setPoint(2, sf::Vector2f(0, tileSize));
	shape.setPoint(3, sf::Vector2f(tileSize, tileSize));
	shape.setPosition(posX * tileSize, posY * tileSize);
}

void WeaponPickup::Collide(Entity *g){
	if(g->GetOutline().getGlobalBounds().intersects(shape.getGlobalBounds())){
		remove = true;
		g->Collide(this);
	}
}

void WeaponPickup::Collide(Jumper *g){
	if(g->GetOutline().getGlobalBounds().intersects(shape.getGlobalBounds())){
		remove = true;
		g->Collide(this);
	}
}
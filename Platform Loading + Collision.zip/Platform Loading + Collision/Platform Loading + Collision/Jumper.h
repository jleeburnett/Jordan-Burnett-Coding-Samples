#pragma once
#include "stdafx.h"
#include "Entity.h"
#include "PlayerInput.h"
#include "UI.h"

class WeaponPickup;

class Jumper : public Entity{
public:
	Jumper(PlayerInput &input, UI &ui);
	virtual ~Jumper();

	virtual void Update(double interpolation, std::vector<WorldObject*> &objs, sf::Clock &clock){
		//input->Update(this, objs);

		if(input->GetMoveLeft()){
			velocity.x = -1 * maxHorizVelocity;
			facingLeft = true;
		}
		if(input->GetMoveRight()){
			velocity.x = maxHorizVelocity;
			facingLeft = false;
		}
		if(input->GetMoveLeft() && input->GetMoveRight()){
			velocity.x = 0;
		}
		if(!input->GetMoveLeft() && !input->GetMoveRight()){
			velocity.x = 0;
		}
		if(input->GetJump() && canJump && collided){
			velocity.y -= jumpVelocity;
		}
		if(input->GetAttack() && input->GetUpReleased()){
			EntityAttack(objs, clock);
			input->UpReleased(false);
		}

		physics.Update(velocity, interpolation);

		Move(velocity);

		collided = false;

		CollisionCheck();
	}

	virtual void TakeDamage(int damage){
		Entity::TakeDamage(damage);

		ui->UpdateHealth(damage / maxHealth);
	}

	virtual void LoadForNewLevel(Level &level);

	virtual void Collide(Endpoint *g);
	virtual void Collide(WeaponPickup *g);
	virtual void Collide(Entity *g);
private:
	int maxHealth;
	UI *ui;
};
#pragma once
#include "stdafx.h"
#include "Level.h"
#include "Jumper.h"
#include "Gridsquare.h"
#include "UI.h"
#include <iostream>

//I need to set up the game so that everything that will exist for any loaded level is created at load time, but to save speed then only enemies within a certain
//radius and/or have an updatable flag set to true are actually updated; all others are just passed over
//tl;dr: load all objects at the start and only update objects if(updatable){}

enum Gamestate{
	running, menu, end
};

class Board{
public:
	Board(PlayerInput &input) : SCREEN_WIDTH(1280), SCREEN_HEIGHT(720), tileSize(30), levelNumber(1), maxLevels(2), gamestate(running){
		//instantiate common objects like Players
		objects.push_back(new Jumper(input, ui));
		SetupGrid(sf::Vector2f(0, 0));
		activeLevel.SetActive(objects, levelNumber, tileSize);
	}
	~Board(){}

	void Update(double interpolation, sf::Vector2f &viewPosition, sf::Clock &clock, bool &resetView){
		resetView = false;
		levelLoadedThisFrame = false;
		std::vector<WorldObject*> objs = activeLevel.GetLevelObjects();
		std::vector<sf::Drawable*> drawables;

		sf::FloatRect screen(float(viewPosition.x - SCREEN_WIDTH / 2), float(viewPosition.y - SCREEN_HEIGHT / 2), SCREEN_WIDTH, SCREEN_HEIGHT);

		//can't add to vector while iterating, so add to this vector, then concatenate the two at the end of Update()
		//note all appended objects won't be touched until the next Update() loop
		std::vector<WorldObject*> addedObjects;
		std::vector<int> removeIndex;

		//just do a sweep test here, have each object handle collision in its own update method

		sf::Vector2f gridTopLeft = sf::Vector2f(viewPosition.x - SCREEN_WIDTH / 2, viewPosition.y - SCREEN_HEIGHT / 2);

		SetupGrid(gridTopLeft);

		for(unsigned int i = 0; i < objs.size(); ++i){
			objs[i]->ClearStuff();
			for(unsigned int j = 0; j < grid.size(); ++j){
				if(objs[i]->GetOutline().getGlobalBounds().intersects(grid[j].GetRect())){
					drawables.push_back(&objs[i]->GetDrawable());
					grid[j].AddObject(objs[i]);
					objs[i]->AddGridsquare(&grid[j]);
					objs[i]->SetUpdatable(true);
				}
			}
		}

		for(unsigned int i = 0; i < objs.size(); ++i){
			//perhaps move this check inside WO::Update()
			if(objs[i]->GetUpdatable()){
				objs[i]->Update(interpolation, addedObjects, clock);
			}
			if(objs[i]->GetRemove()){
				removeIndex.push_back(i);
			}
		}

		//for(unsigned int i = 0; i < objs.size(); ++i){
		//	if(sf::FloatRect(objs[i]->GetOutline().getGlobalBounds()).intersects(screen)){
		//		objs[i]->Update(interpolation, addedObjects, clock);
		//		//two options, pass objs as parameter in update so that attacking objects can add their attack objects to the vector, or
		//		//add an if statement here checking whether any object has something they would like to add to objs, then add it here
		//		//I'll do both and compare performance
		//		if(objs[i]->GetRemove()){
		//			removeIndex.push_back(i);
		//		}
		//	}
		//}

		for(unsigned int i = 0; i < removeIndex.size(); ++i){
			if(i < objects.size())
				objs.erase(objs.begin() + removeIndex[i]);
		}
		objs.insert(objs.end(), addedObjects.begin(), addedObjects.end());

		/*for(unsigned int i = 0; i < objs.size(); ++i){
			for(unsigned int j = i; j < objs.size(); ++j){
				if(sf::FloatRect(objs[i]->GetOutline().getGlobalBounds()).intersects(sf::FloatRect(objs[j]->GetOutline().getGlobalBounds()))){
					objs[i]->Collide(objs[j]);
				}
			}
		}*/

		/*qtree.UpdateBounds(screen);
		qtree.ClearNode();
		for(unsigned int i = 0; i < objs.size(); i++){
			if(sf::FloatRect(objs[i]->GetOutline().getGlobalBounds()).intersects(screen)){
				objs[i]->Update(interpolation);
				qtree.Insert(objs[i]);
			}
		}

		for(unsigned int i = 0; i < objs.size(); i++){
			std::vector<WorldObject*> returnObjects;
			qtree.GetPossibleCollisions(objs[i], returnObjects);

			for(unsigned int j = 0; j < returnObjects.size(); j++){
				objs[i]->Collide(returnObjects[j]);
			}
		}*/

		activeLevel.GetLevelObjects() = objs;

		//when I load a new level, nothing loads, I am pretty sure this is due to the position of the grid, so basically just make sure that everything gets
		//reset to 0,0
		if(activeLevel.GetEndLevel()){
			levelNumber++;
			if(levelNumber > maxLevels){
				gamestate = end;
			}
			else{
				SetupGrid(sf::Vector2f(0, 0));
				activeLevel.SetActive(objects, levelNumber, tileSize);
				//need to find and eliminate that bug where levels don't load occassionally
				resetView = true;
				levelLoadedThisFrame = true;
			}
		}

		//return drawables;
	}

	//with the addition of levels, Board has morphed into a level manager class
	//so whenever a level decides that it is completed, Board loads up the next level

	//GETTERS

	Level &GetActiveLevel(){
		return activeLevel;
	}

	Gamestate &GetGamestate(){
		return gamestate;
	}

	UI &GetUI(){
		return ui;
	}

	//replaced by enum
	/*bool GetEndGame(){
		return endGame;
	}*/

	bool GetLevelLoadedThisFrame(){
		return levelLoadedThisFrame;
	}

	//now that I have introduced levels, I need a smart way to manage persistant objects like items and characters vs. level objects like enemies
	std::vector<WorldObject*> &GetObjects(){
		return activeLevel.GetLevelObjects();
	}
private:
	void SetupGrid(sf::Vector2f &topLeft){
		grid.clear();
		int gridsX = 1;
		int gridsY = 1;
		int width = SCREEN_WIDTH / gridsX;
		int height = SCREEN_HEIGHT / gridsY;

		int xCounter = 0, yCounter = 0;
		for(int i = 0; i < (SCREEN_WIDTH / width) * (SCREEN_HEIGHT / height); ++i){
			grid.push_back(Gridsquare(topLeft.x + xCounter * width, topLeft.y + yCounter * height, width, height));

			xCounter++;
			if(xCounter % gridsX == 0){
				xCounter = 0;
				yCounter++;
			}
		}
	}

	Gamestate gamestate;

	UI ui;

	Level activeLevel;
	int levelNumber;
	int maxLevels;
	bool levelLoadedThisFrame;

	float tileSize;

	//Quadtree qtree;

	std::vector<Gridsquare> grid;

	std::vector<WorldObject*> objects;

	const int SCREEN_WIDTH;
	const int SCREEN_HEIGHT;
};
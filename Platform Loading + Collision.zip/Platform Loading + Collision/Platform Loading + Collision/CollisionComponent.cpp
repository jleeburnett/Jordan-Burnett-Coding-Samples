#pragma once
#include "stdafx.h"
#include "CollisionComponent.h"
#include <iostream>

sf::Vector2f Normalize(sf::Vector2f& input){
	if(sqrt(input.x * input.x + input.y * input.y) == 0){
        input.x = 1;
        return input;
    }
    float length = sqrt(input.x * input.x + input.y * input.y);

    input.x /= length;
    input.y /= length;
    return input;
}

sf::Vector2f GetNormalAxis(sf::VertexArray &shape, int index){
	sf::Vector2f vectorOne = shape[index].position;
    sf::Vector2f vectorTwo;
    if(index >= shape.getVertexCount() - 1)
        vectorTwo = shape[0].position;
    else
        vectorTwo = shape[index+1].position;

    sf::Vector2f normalAxis(-(vectorTwo.y - vectorOne.y), vectorTwo.x - vectorOne.x);
    normalAxis = Normalize(normalAxis);
    return normalAxis;
}

float DotProduct(sf::Vector2f &vectorOne, sf::Vector2f &vectorTwo){
    return vectorOne.x * vectorTwo.x + vectorOne.y * vectorTwo.y;
}

float Projection::GetMin(){
	return min;
}
float Projection::GetMax(){
	return max;
}

float Projection::GetOverlap(Projection &projection){
	if(projection.GetMin() <= max && max <= projection.GetMax()){
		return max - projection.GetMin();
	}
	else if(min <= projection.GetMax() && projection.GetMax() <= max){
		return projection.GetMax() - min;
	}
	else{
		return 0;
	}
}

//TODO:
//right now there is a glitch where the jumper will cut through edges of platforms because he is actually closer to the new edge than the one he walked through

sf::Vector2f CollisionComponent::SAT(sf::ConvexShape &objectOne, sf::ConvexShape &objectTwo){
	sf::VertexArray one;
	for(int i = 0; i < objectOne.getPointCount(); i++){
		one.append(sf::Vertex(sf::Vector2f(objectOne.getPosition() - objectOne.getOrigin() + objectOne.getPoint(i))));
	}

	sf::VertexArray two;
	for(int i = 0; i < objectTwo.getPointCount(); i++){
		two.append(sf::Vertex(sf::Vector2f(objectTwo.getPosition() - objectTwo.getOrigin() + objectTwo.getPoint(i))));
	}

	std::vector<sf::Vector2f> axesOne;
	std::vector<sf::Vector2f> axesTwo;
	//for both shapes, get their axes
	for(int i = 0; i < one.getVertexCount(); i++){
		axesOne.push_back(GetNormalAxis(one, i));
	}
	for(int i = 0; i < two.getVertexCount(); i++){
		axesTwo.push_back(GetNormalAxis(two, i));
	}

	//for both sets of axes
	//project
	float overlap = 50000000000;
	sf::Vector2f smallestAxis;
		
	for(int i = 0; i < axesOne.size(); i++){
		Projection projectionOne(axesOne[i], one);
		Projection projectionTwo(axesOne[i], two);

		float o = projectionOne.GetOverlap(projectionTwo);
		if(o == 0.f){
			//no overlap
		}

		if(o < overlap){
			overlap = o;
			smallestAxis = axesOne[i];
		}
	}

	for(int i = 0; i < axesTwo.size(); i++){
		Projection projectionOne(axesTwo[i], one);
		Projection projectionTwo(axesTwo[i], two);

		//but here, GetOverlap() actually returns a non zero number
		float o = projectionOne.GetOverlap(projectionTwo);
		if(o == 0.f){
			//no overlap
		}
		if(o < overlap){
			overlap = o;
			smallestAxis = axesTwo[i];
		}
	}

	sf::Vector2f distance, aPos, bPos;
	aPos = sf::Vector2f(one.getBounds().left + one.getBounds().width / 2, one.getBounds().top + one.getBounds().height / 2);
	bPos = sf::Vector2f(two.getBounds().left + two.getBounds().width / 2, two.getBounds().top + two.getBounds().height / 2);
	distance = aPos - bPos;

	if(DotProduct(distance, smallestAxis) < 0.0f){
		smallestAxis = -smallestAxis;
	}

	return smallestAxis * overlap;
}

Projection::Projection(sf::Vector2f &axis, sf::VertexArray &vertices){
	min = DotProduct(axis, vertices[0].position);
	max = min;

	for(int i = 1; i < vertices.getVertexCount(); i++){
		float proj = DotProduct(axis, vertices[i].position);
		if(proj < min){
			min = proj;
		}
		else if(proj > max){
			max = proj;
		}
	}
}
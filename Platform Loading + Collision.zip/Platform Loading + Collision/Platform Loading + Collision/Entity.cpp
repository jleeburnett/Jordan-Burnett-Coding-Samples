#pragma once
#include "stdafx.h"
#include "Entity.h"
#include "Platform.h"
#include "Jumper.h"

void Entity::Collision(Jumper *g){
	g->Collide(this);
}

void Entity::Collide(Platform *g){
	if(g->GetOutline().getGlobalBounds().intersects(shape.getGlobalBounds())){
		collided = true;
		//do nothing to the platform b/c... it's a platform

		bool canMove = true;

		sf::Vector2f axis = collision.SAT(shape, g->GetOutline());

		//TODO: stop the SAT from glitching through corners
		//I can solve this by testing collisions of shapes + their velocities, not just shapes at their actual positions
		//then instead of moving shapes, testing coll, and moving back, I just test shapes at their projected positions and set their velocities such that they don't
		//collide

		//if collision moved object upwards
		if(axis.x == 0 && (axis.y < 0 || axis.y > 0)){
			//then set vel.y to 0
			//obviously this only holds true for side view games w/ gravity
			velocity.y = 0;

			//this will need to be checked by practically every collision with a solid object
			if(axis.y < 0){
				canJump = true;
			}
			else{
				canJump = false;
			}
		}
		else{
			canJump = false;
		}

		Move(axis);
	}
}

void Entity::Collide(Attack *g){
	if(g->GetOutline().getGlobalBounds().intersects(shape.getGlobalBounds()))
		g->Collide(this);
}
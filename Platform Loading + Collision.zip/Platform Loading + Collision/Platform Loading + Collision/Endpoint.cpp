#include "stdafx.h"
#include "Endpoint.h"
#include "Level.h"
#include "Jumper.h"

void Endpoint::Collide(Jumper *g){
	if(g->GetOutline().getGlobalBounds().intersects(shape.getGlobalBounds()))
		owningLevel->NotifyEnd();
}

void Endpoint::Collide(Entity *g){
	if(g->GetOutline().getGlobalBounds().intersects(shape.getGlobalBounds())){
		if(dynamic_cast<Jumper*>(g)){
			owningLevel->NotifyEnd();	
		}
	}
}
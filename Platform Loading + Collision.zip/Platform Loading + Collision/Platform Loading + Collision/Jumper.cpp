#include "stdafx.h"
#include "Jumper.h"
#include "Endpoint.h"
#include "Level.h"
#include "WeaponPickup.h"

Jumper::Jumper(PlayerInput &in, UI &u){
	input = &in;
	ui = &u;

	collided = false;
	facingLeft = false;

	//jumper can go ahead and start with a bronze Lance
	weapon = new Lance(2);

	LoadEntityJSON(std::string("jumper"));

	maxHealth = health;

	velocity = sf::Vector2f(0.f, 0.f);

	shape.setPointCount(4);
	shape.setPoint(0, sf::Vector2f(width, 0));
	shape.setPoint(1, sf::Vector2f(0, 0));
	shape.setPoint(2, sf::Vector2f(0, height));
	shape.setPoint(3, sf::Vector2f(width, height));

	shape.setFillColor(sf::Color::Blue);
	shape.setOrigin(shape.getGlobalBounds().width / 2, shape.getGlobalBounds().height / 2);
}

Jumper::~Jumper(){

}

void Jumper::LoadForNewLevel(Level &level){
	//set pos to the new level's spawnpoint
	shape.setPosition(level.GetLevelSpawn());
}

void Jumper::Collide(Endpoint *g){
	if(g->GetOutline().getGlobalBounds().intersects(shape.getGlobalBounds()))
		g->Collide(this);
}

void Jumper::Collide(WeaponPickup *g){
	if(g->GetOutline().getGlobalBounds().intersects(shape.getGlobalBounds()))
		weapon = g->GetWeapon();
}

//assume all other entities are hostile
void Jumper::Collide(Entity *g){
	if(g != this){
		if(g->GetOutline().getGlobalBounds().intersects(shape.getGlobalBounds())){
			TakeDamage(g->GetCollisionDamageValue());
		}
	}
}
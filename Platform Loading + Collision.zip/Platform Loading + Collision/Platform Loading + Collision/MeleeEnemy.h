#pragma once
#include "stdafx.h"
#include "MeleeEntityAI.h"
#include "Entity.h"
#include <fstream>

class MeleeEnemy : public Entity{
public:
	MeleeEnemy(int spawnX, int spawnY, int tileSize){
		input = new MeleeEntityAI();

		collided = false;

		LoadEntityJSON(std::string("melee enemy"));

		shape.setPointCount(4);
		shape.setPoint(0, sf::Vector2f(width, 0));
		shape.setPoint(1, sf::Vector2f(0, 0));
		shape.setPoint(2, sf::Vector2f(0, height));
		shape.setPoint(3, sf::Vector2f(width, height));
		shape.setPosition(spawnX * tileSize, spawnY * tileSize);

		shape.setFillColor(sf::Color::Green);
		shape.setOrigin(shape.getGlobalBounds().width / 2, shape.getGlobalBounds().height / 2);
	}
	~MeleeEnemy(){}
};
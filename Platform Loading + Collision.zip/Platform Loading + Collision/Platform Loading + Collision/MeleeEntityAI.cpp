#pragma once
#include "stdafx.h"
#include "MeleeEntityAI.h"
#include "MeleeEnemy.h"

void MeleeEntityAI::Update(Entity *o, std::vector<WorldObject*> &objs){
	ClearInputs();
	if(rand() % 100 < 2){
		jump = true;
	}
	//project possible movements
	//create a horizontal float rect, see what it collides with
	//if it collides with a player, attack
	//if it does not collide, random chance of setting vel for that direction
	//if it collides with a wall, do nothing
	sf::FloatRect horizontalTestLeft(o->GetOutline().getGlobalBounds().left, o->GetOutline().getGlobalBounds().top + o->GetOutline().getGlobalBounds().height / 2, -100, 1);
	//testing this fr against all objects produces around a 4% fr drop, not bad
	for(unsigned int i = 0; i < objs.size(); i++){
		
	}
	//basically do tests like this where one dimension is one pixel. combine the results of the test and decide whether to jump, attack, move, or stand still
}
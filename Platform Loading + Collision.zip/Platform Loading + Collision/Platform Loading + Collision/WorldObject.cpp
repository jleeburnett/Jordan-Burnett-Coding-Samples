#pragma once
#include "stdafx.h"
#include "WorldObject.h"
#include "Gridsquare.h"

void WorldObject::CollisionCheck(){
	//for all gridsquares colliding
		//for all objects of this gridsquare
			//this->Collide(obj[i])
	for(unsigned int i = 0; i < gridsquares.size(); ++i){
		for(unsigned int j = 0; j < gridsquares[i]->GetObjects().size(); ++j){
			this->Collide(gridsquares[i]->GetObjects()[j]);
		}
	}
}
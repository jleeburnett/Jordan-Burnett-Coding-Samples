#pragma once
#include "stdafx.h"
#include "PlayerInput.h"
#include "Jumper.h"

void PlayerInput::Update(Jumper *g, sf::Vector2f &velocity, const int maxHorizVelocity, const int jumpVelocity, bool &facingLeft, bool &canjump, bool &collided, std::vector<WorldObject*> &objs, sf::Clock &clock){
	if(moveLeft){
		velocity.x = -1 * maxHorizVelocity;
		facingLeft = true;
	}
	if(moveRight){
		velocity.x = maxHorizVelocity;
		facingLeft = false;
	}
	if(moveLeft && moveRight){
		velocity.x = 0;
	}
	if(!moveLeft && !moveRight){
		velocity.x = 0;
	}
	if(jump && canjump && collided){
		velocity.y -= jumpVelocity;
	}
	if(attack && upReleased){
		g->EntityAttack(objs, clock);
		upReleased = false;
	}
}
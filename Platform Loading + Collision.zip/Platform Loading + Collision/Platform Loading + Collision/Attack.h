#pragma once
#include "stdafx.h"
#include "WorldObject.h"
#include "WeaponBehavior.h"

//note that I am drawing Attack objects now only to see how the function. In the release version, the attacks will be invisible, and the appearance of the Attack will
//be handled by the caller's own spritesheet
class Attack : public WorldObject{
public:
	Attack(int damage, WeaponBehavior *b, sf::Vector2f &startPos, Entity *e){
		velocity = sf::Vector2f(0, 0);
		attackDamage = damage;
		behavior = b;
		actualStartPos = startPos;
		owner = e;
	}
	virtual ~Attack(){}

	virtual void Update(double interpolation, std::vector<WorldObject*> &objs, sf::Clock &clock){
		behavior->Update(clock, owner, remove, shape, actualStartPos);

		CollisionCheck();
	}

	virtual void Collide(Entity *g);
	virtual void Collide(WorldObject *g){
		g->Collide(this);
	}
protected:
	int attackDamage;
	sf::Vector2f velocity;
	sf::Vector2f actualStartPos;

	Entity *owner;
	WeaponBehavior *behavior;
};
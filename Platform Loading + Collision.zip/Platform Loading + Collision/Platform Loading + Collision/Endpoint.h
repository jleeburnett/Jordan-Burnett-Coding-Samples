#pragma once
#include "stdafx.h"
#include "WorldObject.h"

class Level;

class Endpoint : public WorldObject{
public:
	Endpoint(float posX, float posY, float width, float height, Level *l){
		shape.setPointCount(4);
		shape.setPoint(0, sf::Vector2f(width, 0.f));
		shape.setPoint(1, sf::Vector2f(0.f, 0.f));
		shape.setPoint(2, sf::Vector2f(0.f, height));
		shape.setPoint(3, sf::Vector2f(width, height));
		shape.setPosition(posX * width, posY * height);
		shape.setFillColor(sf::Color::Red);

		owningLevel = l;
	}
	~Endpoint(){}

	virtual void Collide(WorldObject *g){
		g->Collide(this);
	}
	void Collide(Jumper *g);
	void Collide(Entity *g);
private:
	Level *owningLevel;
};
#pragma once
#include "stdafx.h"

class PhysicsComponent{
public:
	PhysicsComponent() : SCREEN_WIDTH(1280), SCREEN_HEIGHT(720), PIXELS_PER_METER(50){
		gravity = 9.81 / PIXELS_PER_METER;
	}
	~PhysicsComponent(){}

	void Update(sf::Vector2f &velocity, double interpolation){
		velocity.y += gravity * float(interpolation);
		velocity.x *= float(interpolation);
	}
private:
	float PIXELS_PER_METER;
	float gravity;
	const int SCREEN_WIDTH;
	const int SCREEN_HEIGHT;
};
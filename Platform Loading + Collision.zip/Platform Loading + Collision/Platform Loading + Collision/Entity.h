#pragma once
#include "stdafx.h"
#include "WorldObject.h"
#include "PhysicsComponent.h"
#include "CollisionComponent.h"
#include "Weapon.h"
#include "Input.h"

class Entity : public WorldObject{
public:
	virtual void Update(double interpolation, std::vector<WorldObject*> &objs, sf::Clock &clock){
		input->Update(this, objs);

		if(input->GetMoveLeft()){
			velocity.x = -1 * maxHorizVelocity;
			facingLeft = true;
		}
		if(input->GetMoveRight()){
			velocity.x = maxHorizVelocity;
			facingLeft = false;
		}
		if(input->GetMoveLeft() && input->GetMoveRight()){
			velocity.x = 0;
		}
		if(!input->GetMoveLeft() && !input->GetMoveRight()){
			velocity.x = 0;
		}
		if(input->GetJump() && canJump && collided){
			velocity.y -= jumpVelocity;
		}
		if(input->GetAttack()){
			EntityAttack(objs, clock);
		}

		physics.Update(velocity, interpolation);

		Move(velocity);

		collided = false;

		CollisionCheck();
	}

	virtual void TakeDamage(int damage){
		health -= damage;
		if(health <= 0){
			remove = true;
		}
	}

	int GetCollisionDamageValue(){
		//called when the player collides with an enemy; return the enemy's base damage
		return damageVal;
	}

	//move back to protected if necessary
	void EntityAttack(std::vector<WorldObject*> &objs, sf::Clock &clock){
		//create attack object
		//add object to objs

		if(weapon->IsWeaponReady(clock)){
			if(facingLeft){
				objs.push_back(weapon->GenerateAttack(clock, damageVal, sf::Vector2f(shape.getGlobalBounds().left + shape.getGlobalBounds().width / 2, shape.getGlobalBounds().top + shape.getGlobalBounds().height / 2), handRight, -1, this));
			}
			else{
				objs.push_back(weapon->GenerateAttack(clock, damageVal, sf::Vector2f(shape.getGlobalBounds().left + shape.getGlobalBounds().width / 2, shape.getGlobalBounds().top + shape.getGlobalBounds().height / 2), handRight, 1, this));
			}
		}
	}

	//returns coordinates of entity's hand in relation to its center
	//will return different values whether the entity is facing left or right
	sf::Vector2f GetHandCoord(){
		if(!facingLeft){
			return handRight;
		}
		else{
			return sf::Vector2f(handRight.x * -1, handRight.y);
		}
	}

	virtual void Collide(WorldObject *g){
		if(g != this)
			g->Collide(this);
	}
	//all objects need to resolve collisions with their own types
	virtual void Collide(Entity *g){}
	virtual void Collide(Endpoint *g){}
	virtual void Collide(WeaponPickup *g){}
	virtual void Collide(Platform *g);
	//why is this marked as collision and not collide
	virtual void Collision(Jumper *g);
	virtual void Collide(Attack *g);
protected:
	void Move(sf::Vector2f &vel){
		shape.move(vel);
		input->UpdatePos(shape.getPosition());
	}
	
	void LoadEntityJSON(std::string &entityType){
		Json::Value root;
		Json::Reader reader;

		std::ifstream file("level_objects/entities.json", std::ifstream::binary);

		if(!reader.parse(file, root, true)){
	
		}

		width = root[entityType]["width"].asInt();
		height = root[entityType]["height"].asInt();

		health = root[entityType]["health"].asInt();
		damageVal = root[entityType]["damageVal"].asInt();
		maxHorizVelocity = root[entityType]["maxHorizontalVelocity"].asFloat();
		jumpVelocity = root[entityType]["jumpVelocity"].asFloat();
		handRight = sf::Vector2f(root[entityType]["handX"].asInt(), root[entityType]["handY"].asInt());

		file.close();
	}
	
	sf::Vector2f velocity;
	float maxHorizVelocity;
	float jumpVelocity;

	//to handle jumping, calculate after SAT if the player was one something solid in the previous frame. if so, the the player can jump
	bool canJump;
	//another bool to handle jumping, and probably other stuff
	bool collided;

	//Entity stuff
	int width;
	int height;
	int health;
	int damageVal;
	bool facingLeft; //this game does not feature player rotation, so the player can only be facing right or left
	sf::Vector2f handRight; //assuming shapes are horizontally symmetrical, this hand coord can identify both the left and right hand by multiplying the x value in
	//relation to the object's center by -1
	Weapon *weapon;

	double hitRegenTime; //time an entity is invincible after being hurt
	
	Input *input;
	PhysicsComponent physics;
	CollisionComponent collision;
};
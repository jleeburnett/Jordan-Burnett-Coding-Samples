#pragma once
#include "stdafx.h"
#include "Board.h"

const double TICKS_PER_SECOND = 45;
const double SKIP_TICKS = 1000 / TICKS_PER_SECOND;
const double MAX_FRAMESKIP = 30;

//const int SCREEN_WIDTH = 1280;
//const int SCREEN_HEIGHT = 720;

class Engine{
public:
	Engine() : board(pInput), resetView(false){
		sf::ContextSettings settings;
		settings.antialiasingLevel = 8;
		window.create(sf::VideoMode(SCREEN_WIDTH, SCREEN_HEIGHT, 32), "Platformer", sf::Style::Default, settings);
		viewPosition = sf::Vector2f(0, 0);
	}
	~Engine(){}

	double Go(){
		sf::Clock clock;
		double nextGameTick = clock.restart().asMilliseconds();
		double lastTick = clock.getElapsedTime().asMilliseconds();
		int frames = 0;
		int loops = 0;
		double interpolation;
		while(window.isOpen()){
			while(nextGameTick < clock.getElapsedTime().asMilliseconds() && loops < MAX_FRAMESKIP){
				interpolation = (clock.getElapsedTime().asMilliseconds() + SKIP_TICKS - nextGameTick) / SKIP_TICKS;
				Process();
				//a better name would be move or something, because it will move() sprites by their velocities * time elapsed
				Update(interpolation, clock);
				if(board.GetGamestate() == end){
					//okay my fps is literally a thousand right now so let's not worry about spatial partitioning until it hits 60
					double fps = frames / clock.getElapsedTime().asSeconds();
					return fps;
				}
				double time = clock.getElapsedTime().asMilliseconds() - lastTick;
				lastTick = clock.getElapsedTime().asMilliseconds();
				nextGameTick += SKIP_TICKS;
				loops++;
			}
			loops = 0;
			//simply draw everything
			Render();
			frames++;
		}

		double fps = frames / clock.getElapsedTime().asSeconds();
		return fps;
	}
private:
	void Process(){
		sf::Event e;
		while(window.pollEvent(e)){
			switch(e.type){
			case sf::Event::Closed:
				window.close();
				break;
			case sf::Event::KeyPressed:
				if(e.key.code == sf::Keyboard::Escape){
					window.close();
				}
			default:
				break;
			}
		}
		//when including a player, make a sf::FloatRect that the player can move around in, then if the player steps outside of that then move the camera center by his		velocity
		//perhaps just move this to PlayerInput
		pInput.ClearInputs();
		if(sf::Keyboard::isKeyPressed(sf::Keyboard::A)){
			pInput.MoveLeft();
		}
		if(sf::Keyboard::isKeyPressed(sf::Keyboard::D)){
			pInput.MoveRight();
		}
		if(sf::Keyboard::isKeyPressed(sf::Keyboard::Space)){
			pInput.Jump();
		}
		if(sf::Keyboard::isKeyPressed(sf::Keyboard::Up)){
			pInput.Attack();
		}
		else{
			pInput.UpReleased(true);
		}
	}

	void Engine::Update(double interpolation, sf::Clock &clock){
		//drawables = board.Update(interpolation, viewPosition, clock, resetView);
		board.Update(interpolation, viewPosition, clock, resetView);
	}

	void Engine::Render(){
		sf::View view(pInput.GetPlayerPos(), sf::Vector2f(float(SCREEN_WIDTH), float(SCREEN_HEIGHT)));
		window.setView(view);
		viewPosition = view.getCenter();

		if(resetView){
			viewPosition = sf::Vector2f(0, 0);
		}

		board.GetUI().UpdatePosition(viewPosition);

		if(!board.GetLevelLoadedThisFrame()){
			window.clear();
			for(unsigned int i = 0; i < board.GetActiveLevel().GetLevelObjects().size(); i++){
				window.draw(board.GetActiveLevel().GetLevelObjects()[i]->GetDrawable());
			}
			if(board.GetGamestate() != menu){
				for(unsigned int i = 0; i < board.GetUI().GetDrawables().size(); i++){
					window.draw(*board.GetUI().GetDrawables()[i]);
				}
			}
			/*for(unsigned int i = 0; i < drawables.size(); ++i){
				window.draw(*drawables[i]);
			}*/
			window.display();
		}
		
	}

	bool resetView;

	std::vector<sf::Drawable*> drawables;

	sf::Vector2f viewPosition;

	sf::RenderWindow window;

	Board board;

	PlayerInput pInput;
};
#pragma once
#include "stdafx.h"
#include "WeaponBehavior.h"

class MeleeWeaponBehavior : public WeaponBehavior{
public:
	MeleeWeaponBehavior(double attackTime, double timeOfAttack){
		timeAttackLasts = attackTime;
		timeOfLastAttack = timeOfAttack;
	}
	virtual ~MeleeWeaponBehavior(){}

	virtual void Update(sf::Clock &clock, Entity *owner, bool &remove, sf::ConvexShape &shape, sf::Vector2f &startPos);
};
#pragma once
#include "stdafx.h"
#include "MeleeWeaponBehavior.h"
#include "Attack.h"
#include <fstream>

class Weapon{
public:
	Weapon(){}
	~Weapon(){}

	//give each Attack a pointer to its owner, use fwd dec to Update Attack() as a reg world object then it uses its entity owner as necessary in Update, along with
	//normal params
	virtual Attack *GenerateAttack(sf::Clock &clock, int baseDamage, const sf::Vector2f &origin, sf::Vector2f &topLeft, int xDirection, Entity *e){
		return nullptr;
	}

	bool IsWeaponReady(sf::Clock &clock){
		//return true if time since attack is greater than weapon time
		if(clock.getElapsedTime().asMilliseconds() - timeOfAttack >= weaponReset){
			return true;
		}
		else{
			return false;
		}
	}

	int GetWeaponScale(){
		return weaponScale;
	}
protected:
	double weaponTime; //time that weapon is active
	double weaponReset; //time until weapon can attack again
	double timeOfAttack;

	int weaponDamage;
	int weaponScale; //0 = bronze, 1 = steel, 2 = silver

	std::map<int, std::string> weaponMap;
};

//MELEE WEAPONS

class MeleeWeapon : public Weapon{
public:
	MeleeWeapon(){}
	MeleeWeapon(int wScale){
		weaponMap[0] = "bronze";
		weaponMap[1] = "steel";
		weaponMap[2] = "silver";

		weaponScale = wScale;
	}
	virtual ~MeleeWeapon(){}
protected:
	int width;
	int height;
};


class Lance : public MeleeWeapon{
public:
	Lance(int wScale) : MeleeWeapon(wScale){
		Json::Value root;
		Json::Reader reader;
		std::ifstream file("level_objects/weapons.json", std::ifstream::binary);

		if(!reader.parse(file, root, true)){

		}

		width = root[weaponMap[weaponScale] + " lance"]["width"].asInt();
		height = root[weaponMap[weaponScale] + " lance"]["height"].asInt();
		weaponDamage = root[weaponMap[weaponScale] + " lance"]["damage"].asInt();
		weaponTime = root[weaponMap[weaponScale] + " lance"]["weapon time"].asInt();
		weaponReset = root[weaponMap[weaponScale] + " lance"]["weapon reset"].asInt();
	}
	virtual ~Lance(){}

	//xDirection: 1 if facing right, -1 if facing left (it is multiplied by the width to decide the direction the attack should form)
	virtual Attack *GenerateAttack(sf::Clock &clock, int baseDamage, const sf::Vector2f &origin, sf::Vector2f &hand, int xDirection, Entity *e){
		timeOfAttack = clock.getElapsedTime().asMilliseconds();

		if(xDirection != 1 && xDirection != -1){
			xDirection = 1;
		}

		sf::Vector2f pos(origin);
		pos.x += hand.x * xDirection;
		pos.y += hand.y;

		//maybe make a weaponDamageCalculate function to have this calculation in only one spot
		Attack *m = new Attack(weaponDamage + baseDamage / 2, new MeleeWeaponBehavior(weaponTime, clock.getElapsedTime().asMilliseconds()), pos, e);

		//*form* the attack here, make it specific to the weapon caller
		m->GetOutline().setPointCount(3); //lances are pointy, aren't they?
		m->GetOutline().setPoint(0, sf::Vector2f(0, 0));
		m->GetOutline().setPoint(1, sf::Vector2f(0, height));
		m->GetOutline().setPoint(2, sf::Vector2f(width * xDirection, height / 2));
		m->GetOutline().setPosition(pos);
		if(weaponScale == 0){
			m->GetOutline().setFillColor(sf::Color::Yellow);
		}
		else if(weaponScale == 1){
			m->GetOutline().setFillColor(sf::Color::White);
		}
		else if(weaponScale == 2){
			m->GetOutline().setFillColor(sf::Color(180, 180, 180));
		}
		
		return m;
	}
};

class Sword : public MeleeWeapon{

};
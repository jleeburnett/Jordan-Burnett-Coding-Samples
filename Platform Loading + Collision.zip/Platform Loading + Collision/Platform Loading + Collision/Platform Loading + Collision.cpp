// Platform Loading + Collision.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Engine.h"
#include <ctime>

int _tmain(int argc, _TCHAR* argv[])
{
	srand(time(NULL));
	Engine e;
	return e.Go();
}


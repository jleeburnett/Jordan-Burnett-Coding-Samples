#pragma once
#include "stdafx.h"
#include "Input.h"

class PlayerInput : public Input{
public:
	PlayerInput(){
		ClearInputs();
	}
	virtual ~PlayerInput(){}

	//virtual void Update(Jumper* g);
	virtual void Update(Jumper *g, sf::Vector2f &velocity, const int maxHorizVelocity, const int jumpVelocity, bool &facingLeft, bool &canjump, bool &collided, std::vector<WorldObject*> &objs, sf::Clock &clock);

	virtual void UpdatePos(const sf::Vector2f &pos){
		playerPos = pos;
	}

	virtual void UpReleased(bool torf){
		upReleased = torf;
	}

	virtual bool GetUpReleased(){
		return upReleased;
	}

	sf::Vector2f &GetPlayerPos(){
		return playerPos;
	}
private:
	bool upReleased;
	sf::Vector2f playerPos;
};
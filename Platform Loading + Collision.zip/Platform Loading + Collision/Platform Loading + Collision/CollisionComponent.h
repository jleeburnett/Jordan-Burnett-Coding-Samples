#pragma once
#include "stdafx.h"

sf::Vector2f Normalize(sf::Vector2f& input);

sf::Vector2f GetNormalAxis(sf::ConvexShape &shape, int index);

float DotProduct(sf::Vector2f &vectorOne, sf::Vector2f &vectorTwo);

class Projection{
public:
	Projection(sf::Vector2f &axis, sf::ConvexShape &vertices);
	Projection(sf::Vector2f &axis, sf::VertexArray &vertices);
	~Projection(){}

	float GetMin();
	float GetMax();

	float GetOverlap(Projection &projection);
private:
	float min, max;
};

class CollisionComponent{
public:
	sf::Vector2f SAT(sf::ConvexShape &objectOne, sf::ConvexShape &objectTwo);

	sf::Vector2f SAT(sf::VertexArray &object, sf::VertexArray &objectTwo);
};
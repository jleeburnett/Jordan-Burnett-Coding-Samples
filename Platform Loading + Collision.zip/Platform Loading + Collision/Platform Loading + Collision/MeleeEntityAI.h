#pragma once
#include "stdafx.h"
#include "Input.h"

class MeleeEntityAI : public Input{
public:
	MeleeEntityAI(){}
	virtual ~MeleeEntityAI(){}

	virtual void Update(Entity *o, std::vector<WorldObject*> &objs);
};
#pragma once
#include "stdafx.h"

class Quadtree{
public:
	Quadtree(sf::FloatRect &bounds, int level) : maxObjects(1), maxLevels(1){
		node = bounds;
		nodeLevel = level;
	}

	void UpdateBounds(sf::FloatRect &bounds){
		node = bounds;
	}

	void ClearNode(){
		objects.clear();
		for(unsigned int i = 0; i < children.size(); i++){
			children[i]->ClearNode();
		}
		children.clear();
	}

	void Subdivide(){
		children.push_back(new Quadtree(sf::FloatRect(node.left + node.width / 2, node.top, node.width / 2, node.height / 2), nodeLevel + 1));
		children.push_back(new Quadtree(sf::FloatRect(node.left, node.top, node.width / 2, node.height / 2), nodeLevel + 1));
		children.push_back(new Quadtree(sf::FloatRect(node.left, node.top + node.height / 2, node.width / 2, node.height / 2), nodeLevel + 1));
		children.push_back(new Quadtree(sf::FloatRect(node.left + node.width / 2, node.top + node.height / 2, node.width / 2, node.height / 2), nodeLevel + 1));
	}

	int GetIndex(sf::FloatRect &objBounds){
		int index = -1;
	    double verticalMidpoint = node.left + (node.width / 2);
	    double horizontalMidpoint = node.top + (node.height / 2);
 
	    // Object can completely fit within the top quadrants
		bool topQuadrant = (objBounds.top < horizontalMidpoint && objBounds.top + objBounds.height < horizontalMidpoint);
	    //bool topQuadrant = (pRect.getY() < horizontalMidpoint && pRect.getY() + pRect.getHeight() < horizontalMidpoint);

	    // Object can completely fit within the bottom quadrants
		bool bottomQuadrant = (objBounds.top > horizontalMidpoint);
	    //bool bottomQuadrant = (pRect.getY() > horizontalMidpoint);
  
	    // Object can completely fit within the left quadrants
	   /* if(pRect.getX() < verticalMidpoint && pRect.getX() + pRect.getWidth() < verticalMidpoint) {
			if (topQuadrant) {
				index = 1;
			}
			else if (bottomQuadrant) {
				index = 2;
			}
		}*/

		if(objBounds.left < verticalMidpoint && objBounds.left + objBounds.width < verticalMidpoint){
			if(topQuadrant){
				index = 1;
			}
			else if(bottomQuadrant){
				index = 2;
			}
		}

		// Object can completely fit within the right quadrants
		/*else if (pRect.getX() > verticalMidpoint) {
			if (topQuadrant) {
				index = 0;
			}
			else if (bottomQuadrant) {
				index = 3;
			}
		}*/

		else if(objBounds.left > verticalMidpoint){
			if(topQuadrant){
				index = 0;
			}
			else if(bottomQuadrant){
				index = 3;
			}
		}
 
		return index;
	}

	void Insert(WorldObject *obj){
		if(children.size() > 0){
			int index = GetIndex(obj->GetOutline().getGlobalBounds());

			if(index != -1){
				children[index]->Insert(obj);
			}
		}
		else{
			objects.push_back(obj);
			if(objects.size() > maxObjects && nodeLevel < maxLevels){
				if(children.size() == 0){
					Subdivide();
				}

				unsigned int i = 0;
				while(i < objects.size()){
					int index = GetIndex(obj->GetOutline().getGlobalBounds());
					if(index != -1){
						children[index]->Insert(obj);
						objects.erase(objects.begin() + i);
					}
					else{
						i++;
					}
				}

				/*for(unsigned int i = 0; i < objects.size(); i++){
					int index = GetIndex(objects[i]->GetOutline().getGlobalBounds());
					if(index != -1){
						children[index]->Insert(objects[i]);
						objects.erase(objects.begin() + i);
					}
				}*/
			}
		}
	}

	std::vector<WorldObject*> &GetPossibleCollisions(WorldObject *obj, std::vector<WorldObject*> &pObjects){
		//my theory is that this getindex method is bogus and I need to simply check if the object intersects any children's bounds, then if it does
		//add the child's objects to pObjects
		/*int index = GetIndex(obj->GetOutline().getGlobalBounds());
		if(index != -1 && children.size() > 0){
			children[index]->GetPossibleCollisions(obj, pObjects);
		}*/

		for(unsigned int i = 0; i < children.size(); i++){
			if(sf::FloatRect(obj->GetOutline().getGlobalBounds()).intersects(children[i]->GetNode())){
				children[i]->GetPossibleCollisions(obj, pObjects);
			}
		}

		pObjects.insert(pObjects.end(), objects.begin(), objects.end());

		return pObjects;
	}

	sf::FloatRect &GetNode(){
		return node;
	}
private:
	const unsigned int maxObjects;
	const unsigned int maxLevels;

	sf::FloatRect node;

	int nodeLevel;

	std::vector<WorldObject*> objects;
	std::vector<Quadtree*> children;
};
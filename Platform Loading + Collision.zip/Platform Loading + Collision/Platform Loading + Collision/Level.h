#pragma once
#include "stdafx.h"
#include "Platform.h"
#include "Endpoint.h"
#include "MeleeEnemy.h"
#include "Weapon.h"
#include "WeaponPickup.h"

class Level{
public:
	Level() : endLevel(false){}
	~Level(){}

	void SetActive(std::vector<WorldObject*> &permObjects, int levelNumber, float tileSize){
		ResetVals();
		//set vals, but don't create any new objects
		std::string currentLevel("levels.level" + std::to_string(levelNumber));

		//the second thing I want to do when loading a level is give it access to all perm objects, which are held in Board
		objects.insert(objects.end(), permObjects.begin(), permObjects.end());
		int permEnd = objects.size();
		//the Level then goes through and calls LoadForNewLevel on all those perms, efficiently setting all the perm objects

		//parse given level file for all relevant startup info
		std::ifstream fin;
		std::string str("levels/level" + std::to_string(levelNumber) + ".txt");
		fin.open(str);
		int yCounter = 0; //incr whenever file reads /n
		std::string line;
		//this happens once per line, so whenever the while statement breaks, that means incr yCounter
		while(std::getline(fin, line)){
			for(unsigned int xCounter = 0; xCounter < line.length(); xCounter++){
				if(line[xCounter] == 'w'){
					AddWall(float(xCounter), float(yCounter), tileSize);
				}
			}
			yCounter++;
		}
		fin.close();
		//now parse the level mask. the level file holds all physical objects, like walls, and the mask holds all spawnpoints and intangible objects
		str = "levels/level" + std::to_string(levelNumber) + "mask.txt";
		fin.open(str);
		yCounter = 0;
		line.clear();
		while(std::getline(fin, line)){
			for(unsigned int xCounter = 0; xCounter < line.length(); xCounter++){
				if(line[xCounter] == 'm'){
					objects.push_back(new MeleeEnemy(xCounter, yCounter, tileSize));
				}
				else if(line[xCounter] == 'l'){
					objects.push_back(new WeaponPickup(new Lance(rand() % 3), xCounter, yCounter, tileSize));
				}
				else if(line[xCounter] == 'f'){
					objects.push_back(new Endpoint(float(xCounter), float(yCounter), tileSize, tileSize, this));
				}
				else if(line[xCounter] == 's'){
					spawnPoint.x = xCounter * tileSize;
					spawnPoint.y = yCounter * tileSize;
				}
			}
			yCounter++;
		}

		for(unsigned int i = 0; i < permEnd; i++){
			objects[i]->LoadForNewLevel(*this);
		}

		fin.close();
	}

	void NotifyEnd(){
		endLevel = true;
	}

	bool GetEndLevel(){
		return endLevel;
	}

	//I need a better way to handle permanent objects rather than getting all the level's characteristics
	sf::Vector2f &GetLevelSpawn(){
		return spawnPoint;
	}

	std::vector<WorldObject*> &GetLevelObjects(){
		return objects;
	}
private:
	void ResetVals(){
		endLevel = false;
		objects.clear();
	}
	//now, if I want to modify my walls, eg one level will have all white walls while another will have blue walls, I can create different types of platform
	//objects, such as wall platform and ground platform, then the level can read its own data and if it is eg an outside-based level it can tell all of its
	//ground tiles to set their texture to grass. Of course, basic type differentiation can be done by filling my txt files with different letter
	void AddWall(float posX, float posY, float tileSize){
		//create a wall with given pos's and store it
		objects.push_back(new Platform(posX, posY, tileSize));
	}

	//for now I can only have one element for testing the end of the level, and that is if the player touches the endpoint
	//I can create a list of bools for each level, and the current level can sort through the list that coincides with its activeLevel number to satisfy all of its
	//endgame components
	bool endLevel;

	sf::Vector2f spawnPoint;

	std::vector<WorldObject*> objects;
};
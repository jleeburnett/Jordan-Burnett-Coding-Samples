#pragma once
#include "stdafx.h"
#include "Attack.h"
#include "MeleeEnemy.h"

void Attack::Collide(Entity *g){
	//if not colliding with wielder (or maybe I would want self-fire for certain projectiles...)
	//at the very least, deal damage to the victim. other behavior can override this func
	if(g->GetOutline().getGlobalBounds().intersects(shape.getGlobalBounds())){
		if(owner != g)
			g->TakeDamage(attackDamage);
	}
}
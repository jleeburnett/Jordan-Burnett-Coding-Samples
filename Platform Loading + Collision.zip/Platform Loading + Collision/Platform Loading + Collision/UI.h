#pragma once
#include "stdafx.h"

const int SCREEN_WIDTH = 1280;
const int SCREEN_HEIGHT = 720;

class UI{
public:
	UI(){
		healthbar.setSize(sf::Vector2f(SCREEN_WIDTH / 3, SCREEN_HEIGHT / 20));
		healthbar.setFillColor(sf::Color::Red);
		healthbarPosition = sf::Vector2f(healthbar.getSize().x + SCREEN_WIDTH / 6, -(SCREEN_HEIGHT / 2 - healthbar.getSize().y));
	}
	~UI(){}

	void UpdatePosition(sf::Vector2f &viewposition){
		healthbar.setPosition(viewposition - healthbarPosition);
	}

	void UpdateHealth(int deltaHealthRatio){
		healthbar.setSize(sf::Vector2f(healthbar.getSize().x * deltaHealthRatio, healthbar.getSize().y));
	}

	std::vector<sf::Drawable*> GetDrawables(){
		std::vector<sf::Drawable*> drawables;
		drawables.push_back(&healthbar);

		return drawables;
	}
private:
	sf::RectangleShape healthbar;
	sf::Vector2f healthbarPosition;

	//other pairs of ui objects and their positions relative to center of screen
};
#pragma once
#include "stdafx.h"
#include "WorldObject.h"

class Platform : public WorldObject{
public:
	Platform(){}
	Platform(float posX, float posY, float tileSize){
		shape.setPointCount(4);
		shape.setPoint(0, sf::Vector2f(tileSize, 0.f));
		shape.setPoint(1, sf::Vector2f(0.f, 0.f));
		shape.setPoint(2, sf::Vector2f(0.f, tileSize));
		shape.setPoint(3, sf::Vector2f(tileSize, tileSize));
		shape.setPosition(posX * tileSize, posY * tileSize);
		shape.setFillColor(sf::Color::White);
	}
	
	virtual void Collide(WorldObject *g){
		g->Collide(this);
	}
	virtual void Collide(Entity *g);
};
#include "stdafx.h"
#include "Platform.h"
#include "Jumper.h"

//collision funcs
void Platform::Collide(Entity *g){
	if(g->GetOutline().getGlobalBounds().intersects(shape.getGlobalBounds()))
		g->Collide(this);
}
#pragma once
#include "stdafx.h"
#include "WorldObject.h"

class Weapon;

//must find a way to make the weaponpickup change colors based on the type of weapon it is holding
class WeaponPickup : public WorldObject{
public:
	WeaponPickup(Weapon *w, int posX, int posY, int tileSize);

	Weapon *GetWeapon(){
		return weapon;
	}

	virtual void Collide(Entity *g);
	virtual void Collide(Jumper *g);
private:
	Weapon* weapon;
};
#pragma once
#include "stdafx.h"

class Jumper;
class Platform;
class Endpoint;
class MeleeEnemy;
class Entity;
class Level;
class Attack;
class MeleeAttack;
class Gridsquare;
class WeaponPickup;

class WorldObject{
public:
	WorldObject() : remove(false), updatable(false){}
	virtual ~WorldObject(){}

	virtual void Update(double interpolation, std::vector<WorldObject*> &objs, sf::Clock &clock){
		CollisionCheck();
	}

	//so here I have a virtual func that I'd prefer to move out of this class, because not all derived classes use this, but until then, it's fine
	//accepts the new level and the object, if it is permanent, does whatever needs to be done, otherwise nothing happens
	virtual void LoadForNewLevel(Level &level){}

	void AddGridsquare(Gridsquare *g){
		gridsquares.push_back(g);
	}
	void ClearStuff(){
		gridsquares.clear();
		updatable = false;
	}
	void SetUpdatable(bool boo){
		updatable = boo;
	}

	sf::Drawable &GetDrawable(){
		return shape;
	}

	sf::ConvexShape &GetOutline(){
		return shape;
	}

	bool GetRemove(){
		return remove;
	}
	bool GetUpdatable(){
		return updatable;
	}

	//collision functions, still want to bring these into another class if I can, but for now I just have two objects
	virtual void Collide(WorldObject *g){}
	virtual void Collide(Jumper *g){}
	virtual void Collide(Entity *g){}
	virtual void Collide(MeleeEnemy *g){}
	virtual void Collide(Platform *g){}
	virtual void Collide(Endpoint *g){}
	virtual void Collide(Attack *g){}
	virtual void Collide(WeaponPickup *g){}
protected:
	void CollisionCheck();
	sf::ConvexShape shape;
	//set to true when the entity dies, wall is broken, etc
	bool remove;
	bool updatable;

	//vec of pointers to colliding gridsquares
	std::vector<Gridsquare*> gridsquares;
};
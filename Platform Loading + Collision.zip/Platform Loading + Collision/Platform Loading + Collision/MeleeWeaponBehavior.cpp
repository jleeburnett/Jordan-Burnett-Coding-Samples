#pragma once
#include "stdafx.h"
#include "MeleeWeaponBehavior.h"
#include "Entity.h"

void MeleeWeaponBehavior::Update(sf::Clock &clock, Entity *owner, bool &remove, sf::ConvexShape &shape, sf::Vector2f &startPos){
	if(clock.getElapsedTime().asMilliseconds() - timeOfLastAttack >= timeAttackLasts){
		remove = true;
	}
	//give each Entity a Hand coord, then in this func update the shape so that it is inline with the object's hand
	shape.setPosition(owner->GetOutline().getGlobalBounds().left + owner->GetOutline().getGlobalBounds().width / 2 + owner->GetHandCoord().x, owner->GetOutline().getGlobalBounds().top + owner->GetOutline().getGlobalBounds().height / 2 + owner->GetHandCoord().y);
}